library(testthat)
library(WIOD)

run_examples(fresh = TRUE, run = FALSE)